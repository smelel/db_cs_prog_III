export enum Calibre{
    C03 = "03",
    C05 = "05",
    C08 = "08"
}